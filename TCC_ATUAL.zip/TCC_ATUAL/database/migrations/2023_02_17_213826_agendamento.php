<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('agendamento', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('id_agenda')->unsigned();
            $table->foreign('id_agenda')->references('id')->on('agenda')->onDelete('cascade')->onUpdate('cascade');
            $table->integer('id_cliente')->unsigned();
            $table->foreign('id_cliente')->references('id')->on('cliente')->onDelete('cascade')->onUpdate('cascade');
            $table->integer('id_autonomo')->unsigned();
            $table->foreign('id_autonomo')->references('id')->on('autonomo')->onDelete('cascade')->onUpdate('cascade');
            $table->dateTime('data_inicio');
            $table->dateTime('data_final');
            $table->string('descricao', 255);
            $table->string('confirmado', 10);
            $table->string('status_cancelado', 10);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::dropIfExists('agendamento');
    }
};
