<?php 

namespace app\Providers\Interfaces;

class autonomoService implements IAutonomoService
{

private $db;

public function __construct()
{}



}