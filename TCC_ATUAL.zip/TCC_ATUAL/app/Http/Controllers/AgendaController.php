<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Models\ModelAutonomo;
use App\Models\Models\ModelAgenda;
use App\Models\Models\ModelAgendamento;
use App\Models\Models\ModelUsuario;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class AgendaController extends Controller
{
    private $objAgenda;
    private $objAutonomo;
    private $objUsuario;
    
    public function __construct()
    {
        $this->objAgenda=new ModelAgenda();
        $this->objAutonomo=new ModelAutonomo();
        $this->objUsuario=new ModelUsuario();
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function visualizar_agenda()
    {
        $agenda=$this->objAgenda->all();
        return view('visualizar_agenda',compact('agenda'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function agenda()
    {
        $autonomo=$this->objAutonomo->all();
        $agenda=$this->objAgenda->all();
        $cliente=$this->objUsuario->all();
        return view('agenda',compact('autonomo', 'cliente', 'agenda'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $agenda = new ModelAgenda();

        if($request->id){
            $agenda = ModelAgenda::find($request->id);
        }
    
        $agenda->id_autonomo = $request['id_autonomo'];
        $agenda->id_usuario = $request['id_usuario'];
        $agenda->data = $request['data'];
        $agenda->descricao = $request['descricao'];
        $agenda->status = $request['status'];

        $agenda->save();
        
        return response()->json(['Success' =>$agenda['validade']]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show_agenda($id)
    {
        $agenda=$this->objAgenda->find($id);
        return view('show_agenda',compact('agenda'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $agenda=$this->objAgenda->find($id);
        return view('agenda',compact('agenda'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $agenda = ModelAgenda::find($request->id);
        $agenda->deleted_at = Carbon::now();
        $agenda->save();
    }
}
