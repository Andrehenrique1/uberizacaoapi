<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Models\ModelAutonomo;
use App\Models\Models\ModelUsuario;
use App\Models\Models\ModelAgenda;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class AutonomoController extends Controller
{
    private $objAutonomo;
    private $objUsuario;
    
    public function __construct()
    {
        $this->objAutonomo=new ModelAutonomo();
        $this->objUsuario=new User(); 
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $autonomo=$this->objAutonomo->all();
        return view('index',compact('autonomo'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $user=$this->objUsuario->all();

        return view('create',compact('user'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       $autonomo = new ModelAutonomo();
       $agenda = new ModelAgenda();

        if($request->id){
            $autonomo = ModelAutonomo::find($request->id);
        }
    
       $autonomo->id_usuario = $request['id_usuario'];
       $autonomo->idade = $request['idade'];
       $autonomo->profissao = $request['profissao'];
       $autonomo->descricao = $request['descricao'];

       //IMAGEM

       if($request->hasFile('image') && $request->file('image')->isValid()) {

            $requestImage = $request->image;

            $extension = $requestImage->extension();

            $imageName = md5($requestImage->getClientOriginalName() . strtotime("now"));

            $requestImage->move(public_path('img/autonomo'), $imageName);

            $autonomo->foto = $imageName;
        }

       $autonomo->save();
        
       $id = $autonomo->id;
       $agenda->id_autonomo = $id;
       $agenda->save();
      
        return response()->json(['Success' =>$autonomo['validade']]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $autonomo=$this->objAutonomo->find($id);
        return view('show',compact('autonomo'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $autonomo=$this->objAutonomo->find($id);
        $user=$this->objUsuario->all();
        return view('create',compact('autonomo','user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $autonomo = ModelAutonomo::find($request->id);
        $autonomo->deleted_at = Carbon::now();
        $autonomo->save();
    }
}
