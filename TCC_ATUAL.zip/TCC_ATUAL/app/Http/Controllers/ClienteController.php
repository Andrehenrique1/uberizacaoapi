<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Models\ModelCliente;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class ClienteController extends Controller
{
    private $objCliente;
    private $objUsuario;
    
    public function __construct()
    {
        $this->objCliente=new ModelCliente();
        $this->objUsuario=new User(); 
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function cliente()
    {
        $cliente=$this->objCliente->all();
        return view('cliente',compact('cliente'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $user=$this->objUsuario->all();

        return view('create',compact('cliente'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       $cliente = new ModelCliente();
       $agenda = new ModelAgenda();

        if($request->id){
            $cliente = ModelCliente::find($request->id);
        }
    
       $cliente->id_usuario = $request['id_usuario'];

       $cliente->save();
      
        return response()->json(['Success' =>$cliente['validade']]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $cliente=$this->objCliente->find($id);
        return view('show',compact('cliente'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $cliente=$this->objCliente->find($id);
        $user=$this->objUsuario->all();
        return view('create',compact('cliente','user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $cliente = ModelCliente::find($request->id);
        $cliente->deleted_at = Carbon::now();
        $cliente->save();
    }
}
