<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Models\ModelAutonomo;
use App\Models\Models\ModelAgenda;
use App\Models\Models\ModelAgendamento;
use App\Models\Models\ModelCliente;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class AgendamentoController extends Controller
{
    private $objAgendamento;
    private $objAgenda;
    private $objAutonomo;
    private $objCliente;
    
    public function __construct()
    {
        $this->objAgendamento=new ModelAgendamento();
        $this->objAgenda=new ModelAgenda();
        $this->objAutonomo=new ModelAutonomo();
        $this->objCliente=new ModelCliente();
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function visualizar_agendamento()
    {
        $agendamento=$this->objAgendamento->all();
        return view('visualizar_agendamento',compact('agendamento'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function agendamento()
    {
        $autonomo=$this->objAutonomo->all();
        $agenda=$this->objAgenda->all();
        $cliente=$this->objCliente->all();
        return view('agendamento',compact('autonomo', 'cliente', 'agenda'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $agendamento = new ModelAgendamento();

        if($request->id){
            $agendamento = ModelAgendamento::find($request->id);
        }
    
        $agendamento->id_autonomo = $request['id_autonomo'];
        $agendamento->id_cliente = $request['id_cliente'];
        $agendamento->id_agenda = $request['id_agenda'];
        $agendamento->data_inicio = $request['data_inicio'];
        $agendamento->data_final = $request['data_final'];
        $agendamento->descricao = $request['descricao'];
        $agendamento->status = $request['confirmado'];
        $agendamento->status_cancelado = $request['status_cancelado'];

        $agendamento->save();
        
        return response()->json(['Success' =>$agendamento['validade']]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show_agendamento($id)
    {
        $agendamento=$this->objAgendamento->find($id);
        return view('show_agendamento',compact('agendamento'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $agendamento=$this->objAgendamento->find($id);
        $autonomo=$this->objAutonomo->all();
        $cliente=$this->objCliente->all();
        $agenda=$this->objAgenda->all();
        return view('agendamento',compact('agendamento','autonomo','cliente','agenda'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $agendamento = ModelAgendamento::find($request->id);
        $agendamento->deleted_at = Carbon::now();
        $agendamento->save();
    }
}
