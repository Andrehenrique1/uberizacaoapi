<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Models\ModelAutonomo;
use App\Models\Models\ModelCliente;
use App\Models\Models\ModelAvaliacao;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class AvaliacaoController extends Controller
{
    private $objAvaliacao;
    private $objAutonomo;
    private $objCliente;
    
    public function __construct()
    {
        $this->objAvaliacao=new ModelAvaliacao();
        $this->objAutonomo=new ModelAutonomo();
        $this->objCliente=new ModelCliente(); 
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function visualizar_avaliacao()
    {
        $avaliacao=$this->objAvaliacao->all();
        return view('visualizar_avaliacao',compact('avaliacao'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function avaliacao()
    {
        $autonomo=$this->objAutonomo->all();
        $cliente=$this->objCliente->all();

        return view('avaliacao',compact('autonomo','cliente'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       $avaliacao = new ModelAvaliacao();

        if($request->id){
            $avaliacao = ModelAvaliacao::find($request->id);
        }
    
       $avaliacao->id_autonomo = $request['id_autonomo'];
       $avaliacao->id_cliente = $request['id_cliente'];
       $avaliacao->avaliacao = $request['avaliacao'];
       $avaliacao->comentario = $request['comentario'];

       $avaliacao->save();
      
        return response()->json(['Success' =>$avaliacao['validade']]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $avaliacao=$this->objAvaliacao->find($id);
        return view('show',compact('avaliacao'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $avaliacao=$this->objAvaliacao->find($id);
        $autonomo=$this->objAutonomo->all();
        $cliente=$this->objCliente->all();
        return view('avaliacao',compact('autonomo','avaliacao', 'cliente'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $avaliacao = ModelAvaliacao::find($request->id);
        $avaliacao->deleted_at = Carbon::now();
        $avaliacao->save();
    }
}
