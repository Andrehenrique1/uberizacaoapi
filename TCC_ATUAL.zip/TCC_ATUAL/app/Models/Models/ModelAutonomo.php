<?php

namespace App\Models\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ModelAutonomo extends Model
{
    use SoftDeletes;

    public $timestamps = true;
    protected $primaryKey = 'id';
    protected $table='autonomo';
    protected $fillable=['id','id_usuario', 'foto', 'idade', 'profissao', 'descricao'];

    public function relnomeAutonomo(){
        return $this->hasOne(related:'App\Models\User',foreignKey:'id',localKey:'id_usuario');
    }
}
