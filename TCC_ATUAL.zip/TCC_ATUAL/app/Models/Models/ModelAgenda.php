<?php

namespace App\Models\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ModelAgenda extends Model
{
    public $timestamps = true;
    protected $primaryKey = 'id';
    protected $table='agenda';
    protected $fillable=['id','id_autonomo'];

    public function retLigacao(){
        return $this->hasOne(related:'App\Models\Models\ModelAutonomo',foreignKey:'id_usuario');
    }

    public function relAutonomos(){
        return $this->hasOne(related:'App\Models\Models\ModelAutonomo',foreignKey:'id',localKey:'id_autonomo');
    }
}
