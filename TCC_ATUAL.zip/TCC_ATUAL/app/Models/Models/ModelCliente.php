<?php

namespace App\Models\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ModelCliente extends Model
{

    public $timestamps = true;
    protected $primaryKey = 'id';
    protected $table='cliente';
    protected $fillable=['id','id_usuario'];

    public function relCliente(){
        return $this->hasOne(related:'App\Models\User',foreignKey:'id',localKey:'id_usuario');
    }
}
