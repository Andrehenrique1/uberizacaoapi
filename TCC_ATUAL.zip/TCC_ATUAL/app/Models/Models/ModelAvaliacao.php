<?php

namespace App\Models\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ModelAvaliacao extends Model
{
    public $timestamps = true;
    protected $primaryKey = 'id';
    protected $table='avaliacao';
    protected $fillable=['id','id_autonomo', 'id_cliente', 'avaliacao', 'comentario'];

    public function retCliente(){
        return $this->hasOne(related:'App\Models\Models\ModelCliente',foreignKey:'id',localKey:'id_cliente');
    }

    public function retAutonomo(){
        return $this->hasOne(related:'App\Models\Models\ModelAutonomo',foreignKey:'id',localKey:'id_autonomo');
    }
}
