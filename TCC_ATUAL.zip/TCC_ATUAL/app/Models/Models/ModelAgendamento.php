<?php

namespace App\Models\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ModelAgendamento extends Model
{
    public $timestamps = true;
    protected $primaryKey = 'id';
    protected $table='agendamento';
    protected $fillable=['id','id_autonomo', 'id_agenda', 'id_cliente', 'data_inicio', 'data_final', 'descricao','confirmado', 'status_cancelado'];

    public function retLigacao(){
        return $this->hasOne(related:'App\Models\Models\ModelAgenda',foreignKey:'id',localKey:'id_agenda');
    }
}
