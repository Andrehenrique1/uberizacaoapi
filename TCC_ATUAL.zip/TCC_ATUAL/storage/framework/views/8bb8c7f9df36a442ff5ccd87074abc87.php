

<?php $__env->startSection('content'); ?>
<h1 class="text-center mt-5 mb-3">Avaliacao</h1>

<div class="text-center mb-5">
  <a href="<?php echo e(url('avaliacao/create')); ?>">
    <button class="btn btn-success">Cadastrar</button>
  </a>
</div>

<div class="col-8 m-auto">
  <table class="table text-center">

    <thead>
      <tr>
      <th scope="col">Id</th>
        <th scope="col">Id_autonomo</th>
        <th scope="col">id_cliente</th>
        <th scope="col">avaliacao</th>
        <th scope="col">comentario</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $avaliacao; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avaliacao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php
          $avaliacao->find($avaliacao->id_autonomo)->retAutonomo;

          $avaliacao->find($avaliacao->id_cliente)->retCliente;
        ?>

        <tr>
          <th scope="row"><?php echo e($avaliacao->id); ?></th>
          <th><?php echo e($avaliacao->id_autonomo); ?></th> 
          <th><?php echo e($avaliacao->id_cliente); ?></th> 
          <th><?php echo e($avaliacao->avaliacao); ?></th> 
          <td><?php echo e($avaliacao->comentario); ?></td>
          <td>
            <a href="<?php echo e(url("avaliacao/$avaliacao->id")); ?>">
              <button class="btn btn-dark">Visualizar</button>
            </a>
            <a href="<?php echo e(url("avaliacao/edit/$avaliacao->id")); ?>">
              <button class="btn btn-primary">Editar</button>
            </a>
            <a href="">
              <button class="btn btn-danger">Excluir</button>
            </a>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\tc2\TCC\resources\views/visualizar_avaliacao.blade.php ENDPATH**/ ?>