

<?php $__env->startSection('content'); ?>
<h1 class="text-center mt-5 mb-5"></h1>

<div class="col-8 m-auto">
  <?php if(isset($agenda)): ?>
    <form name="formEdit" id="formEdit" method="POST" action="<?php echo e(url("agenda/update/$agenda->id")); ?>">
  <?php else: ?>
    <form name="formCad" id="formCad" method="POST" action="<?php echo e(url('agenda/agenda')); ?>">
  <?php endif; ?>

  <?php echo csrf_field(); ?>
    <select class="form-control mb-3" name="id_autonomo" id="id_autonomo" required>
      <option value="">Selecione o autonomo</option>
      <?php $__currentLoopData = $cliente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <select class="form-control mb-3" name="id_cliente" id="id_cliente" required>
      <option value="">Selecione o cliente</option>
      <option value="1">Chriffy</option>
      <option value="1">Marcus</option>
    </select>

    <select class="form-control mb-3" name="id_agenda" id="id_agenda" required>
      <option value="">Selecione a agenda</option>
        <option value="1">chriffy</option>
    </select>

    <input class="form-control mb-3" type="date" name="data_inicio" id="data_inicio" placeholder="data inicio" required>
    <input class="form-control mb-3" type="date" name="data_fim" id="data_fim" placeholder="data fim" required>
    <input class="form-control mb-3" type="text" name="status" id="status" placeholder="status" required>
    <input class="form-control mb-3" type="text" name="descricao" id="descricao" placeholder="Descrição" required>
    <input class="form-control mb-3" type="text" name="status_cancelado" id="status_cancelado" placeholder="status_cancelado" required>
    <input class="btn btn-primary" type="submit" value="Cadastrar" required>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\TC NOVO\TCC\resources\views/agenda.blade.php ENDPATH**/ ?>