

<?php $__env->startSection('content'); ?>
<h1 class="text-center">Visualizar</h1>

<div class="col-8 m-auto">
  <?php
    $nomeusuario=$autonomo->find($autonomo->id)->relnomeAutonomo;
  ?>
  ID Autônomo:<?php echo e($autonomo->id); ?><br>
  ID Usuário:<?php echo e($nomeusuario->id); ?><br>
  Nome:<?php echo e($nomeusuario->name); ?><br>
  Foto:<?php echo e($autonomo->foto); ?><br>
  Idade:<?php echo e($autonomo->idade); ?><br>  
  Profissão:<?php echo e($autonomo->profissao); ?><br>
  Descrição:<?php echo e($autonomo->descricao); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\TC NOVO\TCC\resources\views/show.blade.php ENDPATH**/ ?>