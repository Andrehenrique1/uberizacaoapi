

<?php $__env->startSection('content'); ?>
<h1 class="text-center mt-5 mb-5"></h1>

<div class="col-8 m-auto">
  <?php if(isset($avaliacao)): ?>
    <form name="formEdit" id="formEdit" method="POST" action="<?php echo e(url("avaliacao/update/$avaliacao->id")); ?>">
  <?php else: ?>
    <form name="formCad" id="formCad" method="POST" action="<?php echo e(url('avaliacao/create')); ?>">
  <?php endif; ?>

  <?php echo csrf_field(); ?>
    <select class="form-control mb-3" name="id_autonomo" id="id_autonomo" required>
      <option value="">Selecione o autonomo</option>
      <?php $__currentLoopData = $autonomo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autonomo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($autonomo->id); ?>"><?php echo e($autonomo->id); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <select class="form-control mb-3" name="id_cliente" id="id_cliente" required>
      <option value="">Selecione o cliente</option>
      <?php $__currentLoopData = $cliente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->id); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    

    <input class="form-control mb-3" type="text" name="avaliacao" id="avaliacao" placeholder="avaliacao" required>
    <input class="form-control mb-3" type="text" name="comentario" id="comentario" placeholder="comentario" required>
    <input class="btn btn-primary" type="submit" value="Cadastrar" required>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\tc2\TCC\resources\views/avaliacao.blade.php ENDPATH**/ ?>