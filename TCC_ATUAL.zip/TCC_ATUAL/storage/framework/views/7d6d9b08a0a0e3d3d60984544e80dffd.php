<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?php echo e(url('assets/bootstrap/css/bootstrap.min.css')); ?>">
  <title>Document</title>
</head>
<body>
  <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH E:\Documentos\Repositorios\TCC - CRUD\TCC\resources\views/templates/template.blade.php ENDPATH**/ ?>