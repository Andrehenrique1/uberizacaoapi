

<?php $__env->startSection('content'); ?>
<h1 class="text-center mt-5 mb-3">Autônomos</h1>

<div class="text-center mb-5">
  <a href="<?php echo e(url('autonomo/create')); ?>">
    <button class="btn btn-success">Cadastrar</button>
  </a>
</div>

<div class="col-8 m-auto">
  <table class="table text-center">

    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Nome</th>
        <th scope="col">Foto</th>
        <th scope="col">Idade</th>
        <th scope="col">Profissão</th>
        <th scope="col">Descrição</th>
        <th scope="col">Ações</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $autonomo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autonomos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          $nomeusuario=$autonomos->find($autonomos->id)->relnomeAutonomo;
        ?> 
        <tr>
          <th scope="row"><?php echo e($autonomos->id); ?></th>
          <th><?php echo e($nomeusuario->name); ?></th> 
          <td>
            <div>
              <img src="/img/autonomo/<?php echo e($autonomos->foto); ?>" alt="">
            </div>
          </td>
          <td><?php echo e($autonomos->idade); ?></td>
          <td><?php echo e($autonomos->profissao); ?></td>
          <td><?php echo e($autonomos->descricao); ?></td>
          <td>
            <a href="<?php echo e(url("autonomo/$autonomos->id")); ?>">
              <button class="btn btn-dark">Visualizar</button>
            </a>
            <a href="<?php echo e(url("autonomo/edit/$autonomos->id")); ?>">
              <button class="btn btn-primary">Editar</button>
            </a>
            <a href="">
              <button class="btn btn-danger">Excluir</button>
            </a>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\tc2\TCC_ATUAL\resources\views/index.blade.php ENDPATH**/ ?>