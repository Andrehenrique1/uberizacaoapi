

<?php $__env->startSection('content'); ?>
<h1 class="text-center mt-5 mb-3">Agenda</h1>

<div class="text-center mb-5">
  <a href="<?php echo e(url('agenda/agenda')); ?>">
    <button class="btn btn-success">Cadastrar</button>
  </a>
</div>

<div class="col-8 m-auto">
  <table class="table text-center">

    <thead>
      <tr>
        <th scope="col">IDAgenda</th>
        <th scope="col">Id_autonomo</th>
        <th scope="col">id_cliente</th>
        <th scope="col">data_inicio</th>
        <th scope="col">data_final</th>
        <th scope="col">descricao</th>
        <th scope="col">status</th>
        <th scope="col">status_cancelado</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <!-- <?php
          $autonomo=$agenda->find($agenda->id_autonomo)->relAutonomos;
        ?>  -->

        <?php
          $agn=$agenda->find($agenda->id_autonomo)->retLigacao;
        ?>

        <tr>
          <th scope="row"><?php echo e($agenda->id); ?></th>
          <th><?php echo e($agenda->id_autonomo); ?></th> 

          <th><?php echo e($agenda->data); ?></th> 
          <td><?php echo e($agenda->data); ?></td>
          <td><?php echo e($agenda->descricao); ?></td>
          <td><?php echo e($agenda->status); ?></td>
          <td>
            <a href="<?php echo e(url("agenda/$agenda->id")); ?>">
              <button class="btn btn-dark">Visualizar</button>
            </a>
            <a href="<?php echo e(url("agenda/edit/$agenda->id")); ?>">
              <button class="btn btn-primary">Editar</button>
            </a>
            <a href="">
              <button class="btn btn-danger">Excluir</button>
            </a>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Documentos\Repositorios\TCC - CRUD\TCC\resources\views/visualizar_agenda.blade.php ENDPATH**/ ?>