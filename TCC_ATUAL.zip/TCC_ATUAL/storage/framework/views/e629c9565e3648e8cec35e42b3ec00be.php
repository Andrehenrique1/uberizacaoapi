

<?php $__env->startSection('content'); ?>
<h1 class="text-center mt-5 mb-3">Agendamento</h1>

<div class="text-center mb-5">
  <a href="<?php echo e(url('agendamento/create')); ?>">
    <button class="btn btn-success">Cadastrar</button>
  </a>
</div>

<div class="col-8 m-auto">
  <table class="table text-center">

    <thead>
      <tr>
        <th scope="col">IDAgendamento</th>
        <th scope="col">Id_autonomo</th>
        <th scope="col">id_cliente</th>
        <th scope="col">data_inicio</th>
        <th scope="col">data_final</th>
        <th scope="col">descricão</th>
        <th scope="col">status</th>
        <th scope="col">status_cancelado</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $agendamento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agendamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php
          $agendamento->find($agendamento->id_autonomo)->retLigacao;
        ?>

        <tr>
          <th scope="row"><?php echo e($agendamento->id); ?></th>
          <th><?php echo e($agendamento->id_autonomo); ?></th> 
          <th><?php echo e($agendamento->id_cliente); ?></th>
          <th><?php echo e($agendamento->data_inicio); ?></th> 
          <td><?php echo e($agendamento->data_final); ?></td>
          <td><?php echo e($agendamento->descricao); ?></td>
          <td><?php echo e($agendamento->status); ?></td>
          <td><?php echo e($agendamento->status_cancelado); ?></td>
          <td>
            <a href="<?php echo e(url("agendamento/$agendamento->id")); ?>">
              <button class="btn btn-dark">Visualizar</button>
            </a>
            <a href="<?php echo e(url("agendamento/edit/$agendamento->id")); ?>">
              <button class="btn btn-primary">Editar</button>
            </a>
            <a href="">
              <button class="btn btn-danger">Excluir</button>
            </a>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\tc2\TCC\resources\views/visualizar_agendamento.blade.php ENDPATH**/ ?>