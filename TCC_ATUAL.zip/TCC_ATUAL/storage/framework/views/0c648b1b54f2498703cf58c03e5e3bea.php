

<?php $__env->startSection('content'); ?>
<h1 class="text-center mt-5 mb-5"></h1>

<div class="col-8 m-auto">
  <?php if(isset($autonomo)): ?>
    <form name="formEdit" id="formEdit" method="POST" action="<?php echo e(url("autonomo/update/$autonomo->id")); ?>">
  <?php else: ?>
    <form name="formCad" id="formCad" method="POST" action="<?php echo e(url('autonomo/create')); ?>">
  <?php endif; ?>
  <?php echo csrf_field(); ?>
    <select class="form-control mb-3" name="id_usuario" id="id_usuario" required>
      <option value="">Selecione o usuário</option>
      <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <input class="form-control mb-3" type="text" name="foto" id="foto" placeholder="Foto" required>
    <input class="form-control mb-3" type="text" name="idade" id="idade" placeholder="Idade" required>
    <input class="form-control mb-3" type="text" name="profissao" id="profissao" placeholder="Profissão" required>
    <input class="form-control mb-3" type="text" name="descricao" id="descricao" placeholder="Descrição" required>
    <input class="btn btn-primary" type="submit" value="Cadastrar" required>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Documentos\Repositorios\TCC - CRUD\TCC\resources\views/create.blade.php ENDPATH**/ ?>