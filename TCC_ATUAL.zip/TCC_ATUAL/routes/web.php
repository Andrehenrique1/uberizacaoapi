<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;
use App\Http\Controllers\AutonomoController;
use App\Http\Controllers\AgendaController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth/register');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';

Route::get('/autonomo', 'App\Http\Controllers\AutonomoController@index');
Route::get('/autonomo/create', 'App\Http\Controllers\AutonomoController@create');
Route::get('/autonomo/edit/{id}', 'App\Http\Controllers\AutonomoController@edit');


Route::post('/autonomo/create', 'App\Http\Controllers\AutonomoController@store');
Route::post('/autonomo/update/{id}', 'App\Http\Controllers\AutonomoController@store');
Route::post('/autonomo/delete', 'App\Http\Controllers\AutonomoController@destroy');

Route::get('/autonomo/{id}', 'App\Http\Controllers\AutonomoController@show');

Route::get('/agenda', 'App\Http\Controllers\AgendaController@visualizar_agenda');
Route::get('/agenda/agenda', 'App\Http\Controllers\AgendaController@agenda');
Route::get('/agenda/edit/{id}', 'App\Http\Controllers\AgendaController@edit');

Route::post('/agenda/agenda', 'App\Http\Controllers\AgendaController@store');
Route::post('/agenda/update/{id}', 'App\Http\Controllers\AgendaController@store');
Route::post('/agenda/delete', 'App\Http\Controllers\AgendaController@destroy');

Route::get('/agenda/{id}', 'App\Http\Controllers\AgendaController@show_agenda');



Route::get('/agendamento', 'App\Http\Controllers\AgendamentoController@visualizar_agendamento');
Route::get('/agendamento/create', 'App\Http\Controllers\AgendamentoController@agendamento');
Route::get('/agendamento/edit/{id}', 'App\Http\Controllers\AgendamentoController@edit');

Route::post('/agendamento/create', 'App\Http\Controllers\AgendamentoController@store');
Route::post('/agendamento/update/{id}', 'App\Http\Controllers\AgendamentoController@store');
Route::post('/agendamento/delete', 'App\Http\Controllers\AgendamentoController@destroy');

Route::get('/agendamento/{id}', 'App\Http\Controllers\AgendamentoController@show_agendamento');





Route::get('/avaliacao', 'App\Http\Controllers\AvaliacaoController@visualizar_avaliacao');
Route::get('/avaliacao/create', 'App\Http\Controllers\AvaliacaoController@avaliacao');
Route::get('/avaliacao/edit/{id}', 'App\Http\Controllers\avaliacaoController@edit');

Route::post('/avaliacao/create', 'App\Http\Controllers\AvaliacaoController@store');
Route::post('/avaliacao/update/{id}', 'App\Http\Controllers\AvaliacaoController@store');
Route::post('/avaliacao/delete', 'App\Http\Controllers\AvaliacaoController@destroy');

Route::get('/avaliacao/{id}', 'App\Http\Controllers\AvaliacaoController@show_avaliacao');

