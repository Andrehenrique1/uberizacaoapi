@extends('templates.template')

@section('content')
<h1 class="text-center">Visualizar</h1>

<div class="col-8 m-auto">
  @php
    $nomeusuario=$autonomo->find($autonomo->id)->relnomeAutonomo;
  @endphp
  ID Autônomo:{{$autonomo->id}}<br>
  ID Usuário:{{$nomeusuario->id}}<br>
  Nome:{{$nomeusuario->name}}<br>
  Foto:{{$autonomo->foto}}<br>
  Idade:{{$autonomo->idade}}<br>  
  Profissão:{{$autonomo->profissao}}<br>
  Descrição:{{$autonomo->descricao}}
</div>
@endsection