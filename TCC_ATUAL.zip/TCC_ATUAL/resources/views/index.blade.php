@extends('templates.template')

@section('content')
<h1 class="text-center mt-5 mb-3">Autônomos</h1>

<div class="text-center mb-5">
  <a href="{{url('autonomo/create')}}">
    <button class="btn btn-success">Cadastrar</button>
  </a>
</div>

<div class="col-8 m-auto">
  <table class="table text-center">

    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Nome</th>
        <th scope="col">Foto</th>
        <th scope="col">Idade</th>
        <th scope="col">Profissão</th>
        <th scope="col">Descrição</th>
        <th scope="col">Ações</th>
      </tr>
    </thead>
    <tbody>
      @foreach($autonomo as $autonomos)
        @php
          $nomeusuario=$autonomos->find($autonomos->id)->relnomeAutonomo;
        @endphp 
        <tr>
          <th scope="row">{{$autonomos->id}}</th>
          <th>{{$nomeusuario->name}}</th> 
          <td>
            <div>
              <img src="/img/autonomo/{{$autonomos->foto}}" alt="">
            </div>
          </td>
          <td>{{$autonomos->idade}}</td>
          <td>{{$autonomos->profissao}}</td>
          <td>{{$autonomos->descricao}}</td>
          <td>
            <a href="{{url("autonomo/$autonomos->id")}}">
              <button class="btn btn-dark">Visualizar</button>
            </a>
            <a href="{{url("autonomo/edit/$autonomos->id")}}">
              <button class="btn btn-primary">Editar</button>
            </a>
            <a href="">
              <button class="btn btn-danger">Excluir</button>
            </a>
          </td>
        </tr>
      @endforeach
      
    </tbody>
  </table>
</div>
@endsection