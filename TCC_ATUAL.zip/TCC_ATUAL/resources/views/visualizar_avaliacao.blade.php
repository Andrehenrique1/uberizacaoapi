@extends('templates.template')

@section('content')
<h1 class="text-center mt-5 mb-3">Avaliacao</h1>

<div class="text-center mb-5">
  <a href="{{url('avaliacao/create')}}">
    <button class="btn btn-success">Cadastrar</button>
  </a>
</div>

<div class="col-8 m-auto">
  <table class="table text-center">

    <thead>
      <tr>
      <th scope="col">Id</th>
        <th scope="col">Id_autonomo</th>
        <th scope="col">id_cliente</th>
        <th scope="col">avaliacao</th>
        <th scope="col">comentario</th>
      </tr>
    </thead>
    <tbody>
      @foreach($avaliacao as $avaliacao)

        @php
          $avaliacao->find($avaliacao->id_autonomo)->retAutonomo;

          $avaliacao->find($avaliacao->id_cliente)->retCliente;
        @endphp

        <tr>
          <th scope="row">{{$avaliacao->id}}</th>
          <th>{{$avaliacao->id_autonomo}}</th> 
          <th>{{$avaliacao->id_cliente}}</th> 
          <th>{{$avaliacao->avaliacao}}</th> 
          <td>{{$avaliacao->comentario}}</td>
          <td>
            <a href="{{url("avaliacao/$avaliacao->id")}}">
              <button class="btn btn-dark">Visualizar</button>
            </a>
            <a href="{{url("avaliacao/edit/$avaliacao->id")}}">
              <button class="btn btn-primary">Editar</button>
            </a>
            <a href="">
              <button class="btn btn-danger">Excluir</button>
            </a>
          </td>
        </tr>
      @endforeach
      
    </tbody>
  </table>
</div>
@endsection