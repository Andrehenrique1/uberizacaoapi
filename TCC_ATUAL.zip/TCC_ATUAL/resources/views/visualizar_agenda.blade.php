@extends('templates.template')

@section('content')
<h1 class="text-center mt-5 mb-3">Agenda</h1>

<div class="text-center mb-5">
  <a href="{{url('agenda/agenda')}}">
    <button class="btn btn-success">Cadastrar</button>
  </a>
</div>

<div class="col-8 m-auto">
  <table class="table text-center">

    <thead>
      <tr>
        <th scope="col">IDAgenda</th>
        <th scope="col">Id_autonomo</th>
        <th scope="col">id_cliente</th>
        <th scope="col">data_inicio</th>
        <th scope="col">data_final</th>
        <th scope="col">descricao</th>
        <th scope="col">status</th>
        <th scope="col">status_cancelado</th>
      </tr>
    </thead>
    <tbody>
      @foreach($agenda as $agenda)

        <!-- @php
          $autonomo=$agenda->find($agenda->id_autonomo)->relAutonomos;
        @endphp  -->

        @php
          $agn=$agenda->find($agenda->id_autonomo)->retLigacao;
        @endphp

        <tr>
          <th scope="row">{{$agenda->id}}</th>
          <th>{{$agenda->id_autonomo}}</th> 

          <th>{{$agenda->data}}</th> 
          <td>{{$agenda->data}}</td>
          <td>{{$agenda->descricao}}</td>
          <td>{{$agenda->status}}</td>
          <td>
            <a href="{{url("agenda/$agenda->id")}}">
              <button class="btn btn-dark">Visualizar</button>
            </a>
            <a href="{{url("agenda/edit/$agenda->id")}}">
              <button class="btn btn-primary">Editar</button>
            </a>
            <a href="">
              <button class="btn btn-danger">Excluir</button>
            </a>
          </td>
        </tr>
      @endforeach
      
    </tbody>
  </table>
</div>
@endsection