@extends('templates.template')

@section('content')
<h1 class="text-center mt-5 mb-5"></h1>

<div class="col-8 m-auto">
  @if(isset($agenda))
    <form name="formEdit" id="formEdit" method="POST" action="{{url("agenda/update/$agenda->id")}}">
  @else
    <form name="formCad" id="formCad" method="POST" action="{{url('agenda/agenda')}}">
  @endif

  @csrf
    <select class="form-control mb-3" name="id_autonomo" id="id_autonomo" required>
      <option value="">Selecione o autonomo</option>
      @foreach($autonomo as $autonomo)
        <option value="{{$cliente->id}}">{{$autonomo->id}}</option>
      @endforeach
    </select>

    <select class="form-control mb-3" name="id_agenda" id="id_agenda" required>
      <option value="">Selecione a agenda</option>
        <option value="1">chriffy</option>
    </select>

    <input class="form-control mb-3" type="date" name="data_inicio" id="data_inicio" placeholder="data inicio" required>
    <input class="form-control mb-3" type="date" name="data_fim" id="data_fim" placeholder="data fim" required>
    <input class="form-control mb-3" type="text" name="status" id="status" placeholder="status" required>
    <input class="form-control mb-3" type="text" name="descricao" id="descricao" placeholder="Descrição" required>
    <input class="form-control mb-3" type="text" name="status_cancelado" id="status_cancelado" placeholder="status_cancelado" required>
    <input class="btn btn-primary" type="submit" value="Cadastrar" required>
  </form>
</div>
@endsection