@extends('templates.template')

@section('content')
<h1 class="text-center mt-5 mb-5"></h1>

<div class="col-8 m-auto">
  @if(isset($agendamento))
    <form name="formEdit" id="formEdit" method="POST" action="{{url("agendamento/update/$agendamento->id")}}">
  @else
    <form name="formCad" id="formCad" method="POST" action="{{url('agendamento/create')}}">
  @endif

  @csrf
    <select class="form-control mb-3" name="id_autonomo" id="id_autonomo" required>
      <option value="">Selecione o autonomo</option>
      @foreach($autonomo as $autonomo)
        <option value="{{$autonomo->id}}">{{$autonomo->id}}</option>
      @endforeach
    </select>

    <select class="form-control mb-3" name="id_cliente" id="id_cliente" required>
      <option value="">Selecione o cliente</option>
      @foreach($cliente as $cliente)
        <option value="{{$cliente->id}}">{{$cliente->id}}</option>
      @endforeach
    </select>

    <select class="form-control mb-3" name="id_agenda" id="id_agenda" required>
      <option value="">Selecione o agenda</option>
      @foreach($agenda as $agenda)
        <option value="{{$agenda->id}}">{{$agenda->id}}</option>
      @endforeach
    </select>


    <input class="form-control mb-3" type="date" name="data_inicio" id="data_inicio" placeholder="data inicio" required>
    <input class="form-control mb-3" type="date" name="data_final" id="data_final" placeholder="data final" required>
    <input class="form-control mb-3" type="text" name="confirmado" id="confirmado" placeholder="confirmado" required>
    <input class="form-control mb-3" type="text" name="descricao" id="descricao" placeholder="Descrição" required>
    <input class="form-control mb-3" type="text" name="status_cancelado" id="status_cancelado" placeholder="status_cancelado" required>
    <input class="btn btn-primary" type="submit" value="Cadastrar" required>
  </form>
</div>
@endsection