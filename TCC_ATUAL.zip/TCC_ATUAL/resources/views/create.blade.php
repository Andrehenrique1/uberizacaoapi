@extends('templates.template')

@section('content')
<h1 class="text-center mt-5 mb-5"></h1>

<div class="col-8 m-auto">
  @if(isset($autonomo))
    <form enctype="multipart/form-data" name="formEdit" id="formEdit" method="POST" action="{{url("autonomo/update/$autonomo->id")}}">
  @else
    <form enctype="multipart/form-data" name="formCad" id="formCad" method="POST" action="{{url('autonomo/create')}}">
  @endif
  @csrf
    <select class="form-control mb-3" name="id_usuario" id="id_usuario" required>
      <option value="">Selecione o usuário</option>
      @foreach($user as $user)
        <option value="{{$user->id}}">{{$user->name}}</option>
      @endforeach
    </select>

    <input class="from-control-file" type="file" name="image" id="image"  required>
    <input class="form-control mb-3" type="text" name="idade" id="idade" placeholder="Idade" required>
    <input class="form-control mb-3" type="text" name="profissao" id="profissao" placeholder="Profissão" required>
    <input class="form-control mb-3" type="text" name="descricao" id="descricao" placeholder="Descrição" required>
    <input class="btn btn-primary" type="submit" value="Cadastrar" required>
  </form>
</div>
@endsection