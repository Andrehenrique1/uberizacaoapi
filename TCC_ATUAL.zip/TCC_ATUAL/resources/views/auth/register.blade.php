<x-guest-layout>
    <form method="POST" action="{{ route('register') }}">
        @csrf

        <!-- Name -->
        <div>
            <x-input-label for="name" :value="__('Name')" />
            <x-text-input id="name" class="block mt-1 w-full" type="text" name="name" :value="old('name')" required autofocus autocomplete="name" />
            <x-input-error :messages="$errors->get('name')" class="mt-2" />
        </div>



        <div class="form-group row">
            <label for="cpf" class="col-md-4 col-form-label text-md-right">{{ __('Cpf') }}</label>
            <div class="col-md-6">
                <input id="cpf" type="text" class="form-control" name="cpf" value="{{ old('cpf') }}" required autocomplete="cpf">
            </div>
        </div>

        <div class="form-group row">
            <label for="cidade" class="col-md-4 col-form-label text-md-right">{{ __('Cidade') }}</label>
            <div class="col-md-6">
                <input id="cidade" type="text" class="form-control" name="cidade" value="{{ old('cidade') }}" required autocomplete="cidade">
            </div>
        </div>

        <div class="form-group row">
            <label for="data_nasc" class="col-md-4 col-form-label text-md-right">{{ __('Data_nasc') }}</label>
            <div class="col-md-6">
                <input id="data_nasc" type="date" class="form-control" name="data_nasc" value="{{ old('data_nasc') }}" required autocomplete="data_nasc">
            </div>
        </div>

        <div class="form-group row">
            <label for="telefone" class="col-md-4 col-form-label text-md-right">{{ __('Telefone') }}</label>
            <div class="col-md-6">
                <input id="telefone" type="text" class="form-control" name="telefone" value="{{ old('telefone') }}" required autocomplete="telefone">
            </div>
        </div>

        <div class="form-group row">
            <label for="tipo" class="col-md-4 col-form-label text-md-right">{{ __('Tipo') }}</label>
            <select class="form-control mb-3" name="tipo" id="tipo" required>
                <option value="">Selecione uma opção</option>
                <option value="contratante">Contratante</option> 
                <option value="autonomo">Autônomo</option>
            </select>
        </div>



        <!-- Email Address -->
        <div class="mt-4">
            <x-input-label for="email" :value="__('Email')" />
            <x-text-input id="email" class="block mt-1 w-full" type="email" name="email" :value="old('email')" required autocomplete="username" />
            <x-input-error :messages="$errors->get('email')" class="mt-2" />
        </div>

        <!-- Password -->
        <div class="mt-4">
            <x-input-label for="password" :value="__('Password')" />

            <x-text-input id="password" class="block mt-1 w-full"
                            type="password"
                            name="password"
                            required autocomplete="new-password" />

            <x-input-error :messages="$errors->get('password')" class="mt-2" />
        </div>

        <!-- Confirm Password -->
        <div class="mt-4">
            <x-input-label for="password_confirmation" :value="__('Confirm Password')" />

            <x-text-input id="password_confirmation" class="block mt-1 w-full"
                            type="password"
                            name="password_confirmation" required autocomplete="new-password" />

            <x-input-error :messages="$errors->get('password_confirmation')" class="mt-2" />
        </div>

        <div class="flex items-center justify-end mt-4">
            <a class="underline text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800" href="{{ route('login') }}">
                {{ __('Already registered?') }}
            </a>

            <x-primary-button class="ml-4">
                {{ __('Register') }}
            </x-primary-button>
        </div>
    </form>
</x-guest-layout>
