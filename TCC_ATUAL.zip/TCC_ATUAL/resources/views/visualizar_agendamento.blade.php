@extends('templates.template')

@section('content')
<h1 class="text-center mt-5 mb-3">Agendamento</h1>

<div class="text-center mb-5">
  <a href="{{url('agendamento/create')}}">
    <button class="btn btn-success">Cadastrar</button>
  </a>
</div>

<div class="col-8 m-auto">
  <table class="table text-center">

    <thead>
      <tr>
        <th scope="col">IDAgendamento</th>
        <th scope="col">Id_autonomo</th>
        <th scope="col">id_cliente</th>
        <th scope="col">data_inicio</th>
        <th scope="col">data_final</th>
        <th scope="col">descricão</th>
        <th scope="col">confirmado</th>
        <th scope="col">status_cancelado</th>
      </tr>
    </thead>
    <tbody>
      @foreach($agendamento as $agendamento)

        @php
          $agendamento->find($agendamento->id_autonomo)->retLigacao;
        @endphp

        <tr>
          <th scope="row">{{$agendamento->id}}</th>
          <th>{{$agendamento->id_autonomo}}</th> 
          <th>{{$agendamento->id_cliente}}</th>
          <th>{{$agendamento->data_inicio}}</th> 
          <td>{{$agendamento->data_final}}</td>
          <td>{{$agendamento->descricao}}</td>
          <td>{{$agendamento->confirmado}}</td>
          <td>{{$agendamento->status_cancelado}}</td>
          <td>
            <a href="{{url("agendamento/$agendamento->id")}}">
              <button class="btn btn-dark">Visualizar</button>
            </a>
            <a href="{{url("agendamento/edit/$agendamento->id")}}">
              <button class="btn btn-primary">Editar</button>
            </a>
            <a href="">
              <button class="btn btn-danger">Excluir</button>
            </a>
          </td>
        </tr>
      @endforeach
      
    </tbody>
  </table>
</div>
@endsection